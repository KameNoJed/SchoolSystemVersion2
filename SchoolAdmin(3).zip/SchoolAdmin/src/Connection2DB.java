
import java.sql.Connection;
import java.sql.DriverManager;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Our
 */
public class Connection2DB {
    
    public Connection setConnection() {
        
       
        String dataSourceName= "StudentData.mdb";
        String dir = System.getProperty("user.dir");
        String url = "jdbc:ucanaccess://" + dataSourceName;
        
        Connection con = null;
        try{
            con = DriverManager.getConnection(url);
        }
        catch(Exception e){
            System.out.println(e);
        }
        return con;
    }
 
    
}
