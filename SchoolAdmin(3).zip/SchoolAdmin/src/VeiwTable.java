
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JTable;
import net.proteanit.sql.DbUtils;

public class VeiwTable {
    Connection2DB C = new Connection2DB();
    
    public void Veiw(JTable table){
        try{
            
            Connection con = C.setConnection();
            Statement st = con.createStatement();
            
            String sql = "SELECT * FROM sDetails";
            ResultSet rs = st.executeQuery(sql);
            table.setModel(DbUtils.resultSetToTableModel(rs));
        }catch (Exception ex){
            System.out.println(ex);
        }
    }
    
}
